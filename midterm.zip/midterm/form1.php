
<!DOCTYPE html>
<html>
<head>
<style>


</style>

</head>
<body>
<?php
$file=fopen("text.txt","a");
fwrite($file,$Firstname);
fwrite($file,$Surname);
fclose($file);

?>

<form action="#" method="#">

        <h2>
            passport application - Stage 1</h2>
        
            <p  style="font-weight: bold; color:red"">
                Before filling up the online application form read the guidelines
                carefully.</p>
            <p>
                Fields marked with <span style="color:red">(*)</span> are mandatory.</p>
          
                
           
                                
                    <table cellspacing="2" cellpadding="2">
                        <tr>
                            <td colspan="3">
                                <h3>
                                    Passport Application Information</h3>
                            </td>
                        </tr>
                        <tr>
                            <td width="150">
                             <p>   Applying in:<span style="color:red"> *</span></p>
                            </td>
                            <td>
                                <select >
	<option value="">-SELECT-</option>
	<option value="AUS">Australia</option>
	<option value="AUT">Austria</option>
	<option value="BHR">Bahrain</option>
	<option selected="selected" value="BGD">Bangladesh</option>
	<option value="BEL">Belgium</option>
	<option value="BTN">Bhutan</option>
	<option value="BRA">Brazil</option>
	

</select>
                            </td>
                            
                        </tr>
						  </tr>
                        <tr>
                            <td>
                                Application Type:
                            </td>
                            <td colspan="2">
                                <h4>
                                    NEW APPLICATION</h4>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Passport Type:<span style="color:red"> *</span>
                            </td>
                            <td colspan="2">
                                <select >
	<option selected="selected" value="-1">-SELECT-</option>
	<option value="P">ORDINARY</option>
	<option value="PD">DIPLOMATIC</option>
	<option value="PG">OFFICIAL</option>

</select>
                            </td>
                       
                        <tr>
                            <td>
                                Delivery Type:
                            </td>
                            <td align="left">
                                <table   border="0">
	<tr>
		<td><input  type="radio" name="DeliveryType"  /><label for ="Regular">Regular</label></td>
	</tr><tr>
		<td><input  type="radio" name="DeliveryType"  /><label for ="Express">Express</label></td>
	</tr>
</table>
                            </td>
                            
                        </tr>
                        <!--- Personal Information --->
                        <tr>
                            <td colspan="3">
                                <h3>
                                    Personal Information</h3>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Name of applicant:<span style="color:red"> *</span>
                            </td>
                            <td colspan="2">
                                <input name="FullName" type="text" maxlength="60"   />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                First Part (Given Name):
                            </td>
                            
                            <td colspan="2">
                                <input name="FirstName" type="text" maxlength="28" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Second Part (Surname):<span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <input name="Surname" type="text" maxlength="30"  />
                            </td>
                        </tr>
                        <!--- Guardian Information --->
                        <tr>
                            <td colspan="3">
                                
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <span >Guardian</span>
                                <input  type="checkbox" name="Guardian" /> <span style="color:red">"Tick"</span> <span >
                                        only if Applicant is legally adapted</span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span >Father's name:</span><span style="color:red"> *</span>
                            </td>
                            <td colspan="2">
                                <input name="FatherName" type="text" maxlength="50" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span >Father's Nationality:</span><span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="FatherNat" >
	<option value="">-SELECT-</option>
	<option value="ALB">AFGHANISTAN</option>
	<option value="DZA">ALGERIAN</option>
	<option value="ASM">AMERICAN SAMOAN</option>
	<option value="AUS">AUSTRALIAN</option>
	<option value="AUT">AUSTRIAN</option>
	<option value="BHR">BAHRAINI</option>
	<option selected="selected" value="BGD">BANGLADESHI</option>


</select>
                            </td>
                        </tr>
                        
   <tr>
                            <td>
                                <span id="fProf">Father's Profession:</span><span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="'FatherProf">
	<option selected="selected" value="">-SELECT-</option>
	<option value="1">ACCOUNTANT</option>
	<option value="2">BUSINESS</option>	
	<option value="3">DOCTOR</option>
	<option value="4">DRIVER</option>
	<option value="5">ENGINEER</option>
	<option value="6">OTHERS</option>
	

</select>
                            </td>
                        </tr>
                      
                            
                                   
                        <tr>
                            <td>
                                <span>Mother's name:<span style="color:red">*</span></span>
                            </td>
                            <td colspan="2">
                                <input name="MotherName" type="text" maxlength="50"  />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span>Mother's Nationality:<span style="color:red">*</span></span>
                            </td>
                            <td colspan="2">
                                <select name="MotherNat" >
	<option value="">-SELECT-</option>
	<option value="ALB">AFGHANISTAN</option>	
	<option selected="selected" value="BGD">BANGLADESHI</option>
	<option value="ITA">ITALIAN</option>
	<option value="PRK">KOREAN</option>

	

	

</select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span>Mother's Profession:<span style="color:red">*</span></span>
                            </td>
                            <td colspan="2">
                                <select name="MotherProf" >
	<option selected="selected" value="">-SELECT-</option>
	<option value="35">ACCOUNTANT</option>
	<option value="24">ARTIST</option>
	<option value="13">OTHERS</option>
	<option value="26">TAILOR</option>
	<option value="4">TEACHER</option>
	<option value="12">UNEMPLOYED</option>
	
</select>
                            </td>
                        </tr>
                    
                        <tr>
                            <td>
                                <span>Spouse's name:</span>
                            </td>
                            <td colspan="2">
                                <input name="SpouseName" type="text" maxlength="50" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span>Spouse's Nationality:</span>
                            </td>
                            <td colspan="2">
                                <select name="SpouseNat" >
	<option selected="selected" value="">-SELECT-</option>
	<option value="ALB">AFGHANISTAN</option>
	<option value="AUS">AUSTRALIAN</option>
	<option value="AUT">AUSTRIAN</option>
	<option value="BHS">BAHAMIAN</option>
	<option value="BHR">BAHRAINI</option>
	<option value="BGD">BANGLADESHI</option>
	<option value="USA">AMERICAN</option>
	

</select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <span>Spouse's Profession:</span>
                            </td>
                            <td colspan="2">
                                <select name="SpouseProf" >
	<option selected="selected" value="">-SELECT-</option>
	<option value="3">ACCOUNTANT</option>
	<option value="2">ARTIST</option>
	<option value="5">BACHELOR</option>
	<option value="6">BANKER</option>
	<option value="4">TEACHER</option>
	<option value="1">UNEMPLOYED</option>
	

</select>
                            </td>
                       
                        <tr>
                            <td>
                                Marital Status:<span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="Marital" >
	<option selected="selected" value="">-SELECT-</option>
	<option value="1">SINGLE</option>
	<option value="2">MARRIED</option>
	<option value="3">DIVORCED</option>
	<option value="4">WIDOWED</option>

</select>   
                             </td>
                        </tr> 
 <tr>
                            <td>
                                Applicant's Profession:<span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="Prof" >
	<option selected="selected" value="">-SELECT-</option>
	<option value="35">ACCOUNTANT</option>
	<option value="24">ARTIST</option>
	<option value="1">BACHELOR</option>
	<option value="6">BANKER</option>
	<option value="4">TEACHER</option>
	<option value="12">UNEMPLOYED</option>
	<option value="14">WASHERMAN</option>

</select>
<tr>
                            <td>
                                Country of Birth:<span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="ctl00$ContentPlaceHolder1$ddBirthCountry" id="ctl00_ContentPlaceHolder1_ddBirthCountry" class="validate[required]">
	<option value="">-SELECT-</option>
	<option value="ALB">ALBANIA</option>
	<option value="DZA">ALGERIA</option>
    <option selected="selected" value="BGD">BANGLADESH</option>	
    <option value="PER">PERU</option>
	<option value="PHL">PHILIPPINES</option>
	
	<tr class="trBirthDistrict">
                            <td>
                                Birth District:<span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="BirthDistrict" >
	<option selected="selected" value="">-SELECT-</option>	
	<option value="15">CHITTAGONG</option>
	<option value="19">COMILLA</option>
	<option value="22">COX'S BAZAR</option>
	<option value="26">DHAKA</option>
	<option value="27">DINAJPUR</option>
	<option value="47">KHULNA</option>	
	<option value="91">SYLHET</option>
	<option value="93">TANGAIL</option>
	

</select>
                            </td>
                        </tr>
						
						 <tr>
						 <td>
                                Email:<span style="color:red">*</span>
								</td>
                            
                            <td colspan="2">
                                <input name="Email" type="text" maxlength="50"  />
                            </td>
                        </tr>
	
<form align="right">	
                    <table style="margin-left: 50%;margin-top: -900px;border-left: 0px">
                        <tr>
                            
                        </tr>
                        <tr>
                            <td >
                                Date of Birth:<span style="color:red;" >*</span>
                            </td>
                            <td colspan="2"  >
                                <input name="BirthDate" type="text" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Gender:<span style="color:red">*</span>
                            </td>
                            <td>
							
							
                                <table border="0">
	<tr>
		<td><input  type="radio" name="dGender" value="M" /><label >Male</label></td>
	</tr><tr>
		<td><input type="radio" name="dGender" value="F" /><label >Female</label></td>
	</tr><tr>
		<td><input type="radio" name="Gender" value="X" /><label >Others</label></td>
	</tr>
</table>
        </td>
                        </tr>
                        <tr>
                            <td>
                                Birth ID No:<span class="important">*</span>
                            </td>
                            <td colspan="2">
                                <input name="BirthID" type="text" maxlength="17" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                National ID No.
                            </td>
                            <td colspan="2">
                               <input name="nationalID" type="text" maxlength="17"  />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Tax ID No.
                            </td>
                            <td colspan="2">
                                <table>
                                    <tr>
                                        <td>
                                            <input name="Tax1" type="text" maxlength="17" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Height: <span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <table>
                                    <tr>
                                        <td>
                                            <input name="Height" type="text" maxlength="3" />
                                        </td>
                                        <td>
                                            cm
                                        </td>
                                        <td>
                                            <input name="Height" type="text" maxlength="3"  />
                                        </td>
                                        <td>
                                            inch
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Religion: <span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="Religion" >
	<option selected="selected" >-SELECT-</option>
	<option value="1">BUDDHISM</option>
	<option value="2">CHRISTIANITY</option>
	<option value="3">HINDUISM</option>
	<option value="4">ISLAM</option>	
	<option value="5">OTHERS</option>
	

</select>
                            </td>
                        </tr>
						
                      
						
 <!--- Citizenship Information --->
                        <tr>
                            <td colspan="3">
                                <h3>
                                    Citizenship Information</h3>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Nationality:<span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="Nat" >
	<option value="">-SELECT-</option>
	<option value="ALB">AFGHANISTAN</option>
	<option value="GBR">BRITISH</option>
	<option value="USA">AMERICAN</option>
	<option value="BHR">BAHRAINI</option>
	<option selected="selected" value="BGD">BANGLADESHI</option>
	</select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Citizenship Status:<span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="Citizenship" >
	<option value="">-SELECT-</option>
	<option selected="selected" value="0">BIRTH</option>
	<option value="1">PARENTAGE</option>
	<option value="2">MIGRATION</option>
	<option value="3">NATURALIZATION</option>
	<option value="4">OTHERS</option>

</select>
 <!--Dual Citizenship-->
                        <tr>
                            <td>
                                Dual Citizenship:<span style="color:red">*</span>
                            </td>
                            <td>
                                
                                    <table border="0">
	<tr>
		<td><input type="radio" name="Dual" /><label >Yes</label></td>
	</tr><tr>
		<td><input  type="radio" name="Dual" /><label >No</label></td>
	</tr>
</table>
<!---Present Address --->
                        <tr >
                            <td colspan="3">
                                <h3>
                                    Present Address</h3>
                            </td>
                        </tr>
                        <tr >
                            <td>
                                Village/House:
                            </td>
                            <td colspan="2">
                                <input name="Village" type="text" maxlength="40" />
                            </td>
                        </tr>
                        <tr class="pAdd">
                            <td>
                                Road/Block/Sector:
                            </td>
                            <td colspan="2">
                                <input name="Road" type="text" maxlength="40"/>
                            </td>
                        </tr>
                        <tr >
                            <td>
                                District:<span style="color:red">*</span>
                            </td>
                            <td>
                                
	
                                        <select name="District">
		<option selected="selected" value="">-SELECT-</option>
		<option value="1">COMILLA</option>
		<option value="2">DHAKA</option>
		<option value="3">CHITTAGONG</option>
		<option value="4">BARISHAL</option>
		<option value="5">SHYLET</option>
		<option value="6">Khulna</option>
		</select>
                                    

                            </td>
                        </tr>
                        <tr >
                            <td>
                                Police Station:<span style="color:red">*</span>
                            </td>
                            <td>
                               
	
                                       
	
                                        <select name="PStation" >
										<option selected="selected" value="">-SELECT-</option>
										<option value="1">MIRPUR</option>
										<option value="2">MOTIJHEEL</option>
										<option value="3">KHILGAON</option>
										<option value="4">PAOLTON</option>
										<option value="5">BANANI</option>
										<option value="6">GULSHAN</option>

	</select>
                                    

                            </td>
                        </tr>
						
						<tr >
                            <td>
                                Post Office:<span style="color:red">*</span>
                            </td>
                            <td>
                               
	
                                       
                               
	
                                        <select name="POffice" >
										<option selected="selected" value="">-SELECT-</option>
										<option value="1">MIRPUR</option>
										<option value="2">MOTIJHEEL</option>
										<option value="3">KHILGAON</option>
										<option value="4">PAOLTON</option>
										<option value="5">BANANI</option>
										<option value="6">GULSHAN</option>

	</select>
                                    

                            </td>
                        </tr>
						<!---Permanent Address --->
                        <tr>
                            <td colspan="3">
                                <h3>
                                    Permanent Address</h3>
                            </td>
                        </tr>
                        <tr >
                            <td colspan="3">
                                
	
                                        <input  type="checkbox" name="Same"  />
                                         <span >Same as above</span>
                                    

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Village/House:
                            </td>
                            <td colspan="2">
                                <input name="Village" type="text" maxlength="40" />
                            </td>
                        </tr>
                        <tr class="pAdd">
                            <td>
                                Road/Block/Sector:
                            </td>
                            <td colspan="2">
                                <input name="Road" type="text" maxlength="40"/>
                            </td>
                        </tr>
                        <tr >
                            <td>
                                District:<span style="color:red">*</span>
                            </td>
                            <td>
                                
	
                                        <select name="District">
		<option selected="selected" value="">-SELECT-</option>
		<option value="1">COMILLA</option>
		<option value="2">DHAKA</option>
		<option value="3">CHITTAGONG</option>
		<option value="4">BARISHAL</option>
		<option value="5">SHYLET</option>
		<option value="6">Khulna</option>
		</select>
                                    

                            </td>
                        </tr>
                        <tr >
                            <td>
                                Police Station:<span style="color:red">*</span>
                            </td>
                            <td>
                               
	
                                       
										
                                        <select name="PStation" >
										<option selected="selected" value="">-SELECT-</option>
										<option value="1">MIRPUR</option>
										<option value="2">MOTIJHEEL</option>
										<option value="3">KHILGAON</option>
										<option value="4">PAOLTON</option>
										<option value="5">BANANI</option>
										<option value="6">GULSHAN</option>

	</select>
                                    

                            </td>
                        </tr>
						
						<tr >
                            <td>
                                Post Office:<span style="color:red">*</span>
                            </td>
                            <td>
                               
	
                                       
                               
	
                                        <select name="POffice" >
										<option selected="selected" value="">-SELECT-</option>
										<option value="1">MIRPUR</option>
										<option value="2">MOTIJHEEL</option>
										<option value="3">KHILGAON</option>
										<option value="4">PAOLTON</option>
										<option value="5">BANANI</option>
										<option value="6">GULSHAN</option>

	</select>
                                    

                            </td>
                        </tr>
						 <input type="submit" name="Save" value="Save now &continue in the future" >
               
                    <input type="submit" name="Save" value="save & next"  />
					
						
						
</form>
</body>
</html>
