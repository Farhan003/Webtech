<?php
function count_letters($word,$letter){
$word_len = strlen($word)-1;
$count=0;

for($x = 0; $x <= $word_len; $x++){

if($word[$x] == $letter){
$count++;
}
}
echo "the number of <b> ".$letter."</b> in <b>".$word."</b> is:".$count;
}
count_letters("letter","e");


     
?>