<!DOCTYPE html>
<html>
<head>
</head>

<body>
<?php
?>
<form action="#" method="#">

        <h2>
            passport application - Stage 2 </h2>
        
            <p  style="font-weight: bold; color:Green"">
			online application id: OA0000004008216
                
                .</p>
            <p>
                Fields marked with <span style="color:red">(*)</span> are mandatory.</p>
          
                
           
                                
                    <table cellspacing="2" cellpadding="2">
                        <tr>
                            <td colspan="3">
                                <h3>
                                    Application contact Information</h3>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Office No:
                            </td>
                            <td colspan="2">
                                <input name="" type="text" maxlength="60"   />
                            </td>
                        </tr>
						<tr>
                            <td>
                                Residance No:
                            </td>
                            <td colspan="2">
                                <input name="" type="text" maxlength="60"   />
                            </td>
                        </tr>
						<tr>
                            <td>
                                Mobile No:
                            </td>
                            <td colspan="2">
                                <input name="" type="text" maxlength="60"   />
                            </td>
                        </tr>
						  </tr>
						  
						  <table cellspacing="2" cellpadding="2">
                        <tr>
                            <td colspan="3">
                                <h3>
                                    Emergency contact person's Details</h3>
                            </td>
                        </tr>
                       <tr>
                            <td>
                                Name :<span style="color:red"> *</span>
                            </td>
                            <td colspan="2">
                                <input name="FullName" type="text" maxlength="60"   />
                            </td>
                        </tr>
						<tr>
                            <td>
                                <span >Country:</span><span style="color:red">*</span>
                            </td>
                            <td colspan="2">
                                <select name="FatherNat" >
	<option value="">-SELECT-</option>
	<option value="ALB">AFGHANISTAN</option>
	<option value="DZA">ALGERIAN</option>
	<option value="ASM">AMERICAN SAMOAN</option>
	<option value="AUS">AUSTRALIAN</option>
	<option value="AUT">AUSTRIAN</option>
	<option value="BHR">BAHRAINI</option>
	<option selected="selected" value="BGD">BANGLADESHI</option>


</select>
                            </td>
                        </tr>
						 <tr >
                            <td colspan="3">
                                
	
                                        <input  type="checkbox" name="Same"  />
                                         <span >Same as permanent address</span>
                                    

                            </td>
                        
						
						</tr>
						<tr>
                            <td colspan="3">
                                
	
                                        <input  type="checkbox" name="Same"  />
                                         <span >Same as present address</span>
                                    

                            </td>
                        </tr>
						<tr >
                            <td>
                                Village/House:
                            </td>
                            <td colspan="2">
                                <input name="Village" type="text" maxlength="40" />
                            </td>
                        </tr>
                        <tr class="pAdd">
                            <td>
                                Road/Block/Sector:
                            </td>
                            <td colspan="2">
                                <input name="Road" type="text" maxlength="40"/>
                            </td>
                        </tr>
                        <tr >
                            <td>
                                District:<span style="color:red">*</span>
                            </td>
                            <td>
                                
	
                                        <select name="District">
		<option selected="selected" value="">-SELECT-</option>
		<option value="1">COMILLA</option>
		<option value="2">DHAKA</option>
		<option value="3">CHITTAGONG</option>
		<option value="4">BARISHAL</option>
		<option value="5">SHYLET</option>
		<option value="6">Khulna</option>
		</select>
                                    

                            </td>
                        </tr>
                        <tr >
                            <td>
                                Police Station:<span style="color:red">*</span>
                            </td>
                            <td>
                               
	
                                       
	
                                        <select name="PStation" >
										<option selected="selected" value="">-SELECT-</option>
										<option value="1">MIRPUR</option>
										<option value="2">MOTIJHEEL</option>
										<option value="3">KHILGAON</option>
										<option value="4">PAOLTON</option>
										<option value="5">BANANI</option>
										<option value="6">GULSHAN</option>

	</select>
                                    

                            </td>
                        </tr>
						
						<tr >
                            <td>
                                Post Office:<span style="color:red">*</span>
                            </td>
                            <td>
                               
	
                                       
                               
	
                                        <select name="POffice" >
										<option selected="selected" value="">-SELECT-</option>
										<option value="1">MIRPUR</option>
										<option value="2">MOTIJHEEL</option>
										<option value="3">KHILGAON</option>
										<option value="4">PAOLTON</option>
										<option value="5">BANANI</option>
										<option value="6">GULSHAN</option>

	</select>
                                    

                            </td>
							</tr>
							 <tr>
						 <td>
                                Email :<span style="color:red">*</span>
								</td>
                            
                            <td colspan="2">
                                <input name="Email" type="text" maxlength="50"  />
                            </td>
                        </tr>
						<tr >
                            <td>
                                Relationship:<span style="color:red">*</span>
                            </td>
                            <td>
                               
	
                                       
                               
	
                                        <select name="POffice" >
										<option selected="selected" value="">-SELECT-</option>
										<option value="1">Father</option>
										<option value="2">Mother</option>
										<option value="3">Uncle</option>
										<option value="4">Aunt</option>
										<option value="5">Brother</option>
										<option value="6">Sister</option>
										<option value="6">others</option>

	</select>
                                    

                            </td>
							</tr>
						  </tr>
						  </table>
						  
						   <table style="margin-left: 45%;margin-top: -520px;border-left: 0px">
						    <tr>
                            <td colspan="3">
                                <h3>
                                   Old Passport Information</h3>
                            </td>
                        </tr>
						    <tr>
                            <td >
                                Passport no:
                            </td>
                            <td colspan="2"  >
                                <input name="BirthDate" type="text" />
                            </td>
                        </tr>
						<tr>
                            <td >
                                Place of issue:
                            </td>
                            <td colspan="2"  >
                                <input name="BirthDate" type="text" />
                            </td>
                        </tr>
						<tr>
                            <td >
                                Date of issue:
                            </td>
                            <td colspan="2"  >
                                <input name="BirthDate" type="text" />
                            </td>
                        </tr>
						<tr >
                            <td>
                                Re-Issue reason:
                            </td>
                            <td>
                               
	
                                       
                               
	
                                        <select name="POffice" >
										<option selected="selected" value="">-SELECT-</option>
										<option value="1">Lost</option>
										<option value="2">Renewal</option>
										<option value="3">Change in Bio</option>
										<option value="6">others</option>

	</select>
                                    

                            </td>
							</tr>
							 <input type="submit" name="Save" value="Previous page" >
               
                    <input type="submit" name="Save" value="save & next"  />
					</table>
</body>
</head>
</html>