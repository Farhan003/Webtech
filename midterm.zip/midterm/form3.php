<!DOCTYPE html>
<html>
<head>
</head>

<body>
<?php
?>
<form action="#" method="#">

        <h2>
            passport application - Stage 3 </h2>
        
            <p  style="font-weight: bold; color:Green"">
			online application id: OA0000004008216
                
                .</p>
            <p>
                Fields marked with <span style="color:red">(*)</span> are mandatory.</p>
          
                
           
                                
                    <table cellspacing="2" cellpadding="2">
                        <tr>
                            <td colspan="3">
                                <h3>
                                    Payment Information</h3>
                            </td>
                        </tr>
						<tr>
                            <td>
                                payment Type:
                            </td>
                           
                                <table   border="0">
	<tr>
		<td><input  type="radio" name="DeliveryType"  /><label for ="Regular">Online</label></td>
	</tr><tr>
		<td><input  type="radio" name="DeliveryType"  /><label for ="Express">Non-Online</label></td>
	</tr>
	
	
	<tr>
                            <td colspan="3">
                                
	
                                        <input  type="checkbox" name="Same"  />
                                         <span >Skip payment</span>
                                    

                            </td>
                        </tr>
                         <tr>
                            <td width="150">
                             <p>   Amount:<span style="color:red"> *</span></p>
                            </td>
                            <td>
                                <select >
				<option value="">-SELECT-</option>
				
				<option selected="selected" value="BGD">BDT</option>
				<option value="BEL">US$</option>
				
	

								</select>
                            </td>
                            
                       
						
                            <td colspan="2"  >
                                <input name="BirthDate" type="text" />
                            </td>
							
							</tr>
							 <tr>
                            <td >
                                Date of payment:<span style="color:red;" >*</span>
                            </td>
                            <td colspan="2"  >
                                <input name="BirthDate" type="text" />
                            </td>
                        </tr>
						<tr>
                            <td >
                                Receipt no:<span style="color:red;" >*</span>
                            </td>
                            <td colspan="2"  >
                                <input name="BirthDate" type="text" />
                            </td>
                        </tr>
						<tr >
                            <td>
                                Name of bank:<span style="color:red">*</span>
                            </td>
                            <td>
                               
	
                                       
                               
	
                                        <select name="POffice" >
										<option selected="selected" value="">-SELECT-</option>
										<option value="1">Dhaka Bank</option>
										<option value="2">Ucc Bank</option>
										<option value="3">Modhumoti Bank</option>
										<option value="4">Bangladesh Bank</option>
										<option value="5">Bkb Bank</option>
										<option value="6">Ific Bank</option>
										<option value="6">Islami Bank</option>

	</select>
                                    

                            </td>
							</tr>
							 <tr>
						 <td>
                                Name of Branch :<span style="color:red">*</span>
								</td>
                            
                            <td colspan="2">
                                <input name="Email" type="text" maxlength="50"  />
                            </td>
                        </tr>
						</tr>
						</table>
						<table style="margin-left: 45%;margin-top: -520px;border-left: 0px">
						 <input type="submit" name="Save" value="Previous page" >
               
                    <input type="submit" name="Save" value="save & next"  />
					</table>
					
</body>
</head>
</html>