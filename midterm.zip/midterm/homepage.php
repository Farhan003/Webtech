<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html" />
<meta name="author" content="lolkittens" />
<title>character counter</title>
</head>
<body>
<h2> character counter</h2>
<form action="submit.php" method="POST">
Enter the name:
<table>
<tr>
<input type="text" name="txt"  value="input"/>
<input type="sumbit" name="sumbit" value="Submit" />
</tr>
</table>
</form>
</body>
</html>