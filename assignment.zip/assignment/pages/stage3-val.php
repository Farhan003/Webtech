<?php




 function validation1($fieldName,$value,$name) {
 	global $existValue3;
 	 if(trim($value)=="" || preg_match('[^a-zA-Z0-9]',$value))
 	 {
 	 	error_flag1($fieldName,$value);
 	 	$existValue3[$name]=0;
 	 }
 	 else {
 	 	$existValue3[$name]=1;
 	 	setcookie($name,$value);
 	 }
 	}
 	
//error flag function for text field...........................

 function error_flag1($fieldName,$value) {
	global $errors3;
	$errorString="please enter valid ".$fieldName;
	
	$errors3[]=$errorString;
 } 	

//validation function for select field.........................

 function validation2($fieldName,$value,$name) {
	 global $existValue3;
 	if(trim($value)=='SELECT-' || trim($value)=="")
 	{
 		
 		error_flag2($fieldName,$value);
 		$existValue3[$name]=0;
 	}
 	 else {
 	 	$existValue3[$name]=1;
 	 	setcookie($name,$value);
 	 }
 }


//error flag function for select field...........................

 function error_flag2($fieldName,$value) {
     global $errors3;
	$errorString="please select a ".$fieldName;
	$errors3[]=$errorString;
 } 	
 
 
 function validation3($value,$name) {
 	     global $existValue3;
 		if(trim($value)=='-SELECT-' || trim($value)=="")
 	{
 		$existValue3[$name]=0;
		echo'in';
 	}
 	 else {
 	 	$existValue3[$name]=1;
		
 	 	setcookie($name,$value);
 	 }
 }



 $p=& $_POST;

 

 //$p['delType'];

 validation1('Amount',$p['amnt'],'amnt');
 validation1('Date of Paymemt',$p['dop'],'dop');
 validation1('Receipt No',$p['recno'],'recno');
 validation2('Name of bank',$p['bank'],'bank');
 validation2('Name of Branch',$p['Branch'],'Branch');

 
  

  



  setcookie('existValue3',json_encode($existValue3));
    
   if(!empty($errors3))
   {
   	$ew="fieldError3";
     echo "in";
   setcookie($ew,json_encode($errors3));
  // setcookie('check',json_encode($fieldsOfError));
 
  }
  else{
	   echo "out";
	  setcookie('fieldError3','',time()-3600);
  }
 
 	header('Location: http://localhost/assignment/pages/Final-stage.php');
?>