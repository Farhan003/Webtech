
<!DOCTYPE html>
<html>

	<head>
		<title>Application Form-Stage 2</title>
	</head>
	<script>
	function linkN()
	{
		location.replace("http://localhost/assignment/index.php");
	}
	</script>
	<body>
	
		<h1> PASSPORT APPLICATION - STAGE 2 <h1>
		<h4> Fields marked with <font color="red">(*)</font> are mendatory. </h4>
		<hr>
		<?php
        if(isset($_COOKIE['fieldError2']))
        {
          $e=json_decode($_COOKIE['fieldError2'],true);
          $i=count($e);
          echo "<fieldset>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e[$j] </br>";
          }
          echo "</fieldset>";
        }
        if(isset($_COOKIE['existValue2'])) {
        	 $existValue2=json_decode($_COOKIE['existValue2'], true);
        }
		else {
        	$existValue2=0;
        }
       ?>
		<form action="stage2-val.php" method="POST">
		<table border = "0" width="100%" bgcolor="#eff2f7">
			<tr>
				<td>
				<table border = "0"  align = "left" width ="100%">
				<tr>
					<th colspan = "2" align = "left"><h3>Applicant Contact information</h3><th>
				</tr>
				<tr>
					<td> Office No: </td>
					<td> <input type = "text" name = "ofno" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['ofno']==1) echo $_COOKIE['ofno'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"> </td>
				</tr>
				<tr>
					<td>Residence No:</td>
					<td><input type = "text" name = "resno" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['resno']==1) echo $_COOKIE['resno'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				<tr>
					<td>Mobile No:</td>
					<td><input type = "text" name = "mobno" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['mobno']==1) echo $_COOKIE['mobno'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				<tr>
					<th colspan = "2" align = "left"><h3>Emergency Contact Person's Details</h3><th>
				</tr>
				<tr>
					<td> Name:<font color = "red"><sup>*</sup></font> </td>
					<td> <input type = "text" name = "ename" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['ename']==1) echo $_COOKIE['ename'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"> </td>
				</tr>
				<tr>
					<td>Country:<font color = "red"><sup>*</sup></font></td>
					<td><select name = "ecountry" value="">
								<option value="-SELECT-"><?php if($existValue2!=0)
                                      {
                                      	if($existValue2['ecountry']==1) echo $_COOKIE['ecountry'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?></option>
								
								<option value="BS">Bahamas</option>
								<option value="BH">Bahrain</option>
								<option value="BD">Bangladesh</option>
								<option value="BB">Barbados</option>
								<option value="BY">Belarus</option>
								<option value="BE">Belgium</option>
								<option value="BZ">Belize</option>
								<option value="BJ">Benin</option>
								<option value="BM">Bermuda</option>
							</select>
					</td>				
				</tr>
				<tr colspan = "2">
					<td>
						<br>
						<input type = "checkbox" name = "permaAdd" > Same as permanent address <br>
						<input type = "checkbox" name = "preaAdd" > Same as present address 
					</td>
				</tr>
				<tr>
					<td>Village/House:</td>
					<td><input type = "text" name = "vh" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['vh']==1) echo $_COOKIE['vh'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				<tr>
					<td>Road/Block/Sector:</td>
					<td><input type = "text" name = "rbs" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['rbs']==1) echo $_COOKIE['rbs'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				<tr>
					<td>District:<font color = "red"><sup>*</sup></font></td>
					<td><input type = "text" name = "dis" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['dis']==1) echo $_COOKIE['dis'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				<tr>
					<td>Police Station:<font color = "red"><sup>*</sup></font></td>
					<td><input type = "text" name = "ps" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['ps']==1) echo $_COOKIE['ps'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				<tr>
					<td>Post Office:<font color = "red"><sup>*</sup></font></td>
					<td><input type = "text" name = "po" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['po']==1) echo $_COOKIE['po'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				<tr>
					<td>Contact No:<font color = "red"><sup>*</sup></font></td>
					<td><input type = "text" name = "cn" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['cn']==1) echo $_COOKIE['cn'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				<tr>
					<td>Email:</td>
					<td><input type = "text" name = "email" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['email']==1) echo $_COOKIE['email'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				<tr>
					<td>Relationship:<font color = "red"><sup>*</sup></font></td>
					<td><input type = "text" name = "rlt" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['rlt']==1) echo $_COOKIE['rlt'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
				</tr>
				</table>
				</td>
				
				
				
				<td style = "vertical-align:top" >
				<table border = "0"  align = "top" width = "100%">
					<tr>
						<th colspan = "2" align = "left"><h3>Old Passport Information</h3><th>
					</tr>
					<tr>
						<td>Passport No:</td>
						<td><input type = "text" name = "passNo" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['passNo']==1) echo $_COOKIE['passNo'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
					</tr>
					<tr>
						<td>Place of Issue:</td>
						<td><input type = "text" name = "poi" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['poi']==1) echo $_COOKIE['poi'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
					</tr>
					<tr>
						<td>Date of Issue:</td>
						<td><input type = "text" name = "doi" value=" <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['doi']==1) echo $_COOKIE['doi'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"></td>
					</tr>
					<tr>
						<td>Re-issue Reason:</td>
						<td>
							<select name = "reissue" value="">
								<option value ="-SELECT-"> <?php if($existValue2!=0)
                                      {
                                      	if($existValue2['reissue']==1) echo $_COOKIE['reissue'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-'; ?></option>
								<option value ="expired">EXPIRED</option>
								<option value ="canceled">CANCELED</option>
							</select>
						</td>
					</tr>
				</table>
				</td>
			</tr>
			<tr>
				<td></td>
				<td align = "right"><br> <input type = "button" value= "PREVIOUS PAGE" align = "right" onclick='linkN()' >
						<input type = "submit" value = "SAVE & NEXT" >
				</td>
			</tr>
		</table>
		</form>
		
	</body>
</html>