<?php




 function validation1($fieldName,$value,$name) {
 	global $existValue2;
 	 if(trim($value)=="" || preg_match('[^a-zA-Z]',$value))
 	 {
 	 	error_flag1($fieldName,$value);
 	 	$existValue2[$name]=0;
 	 }
 	 else {
 	 	$existValue2[$name]=1;
 	 	setcookie($name,$value);
 	 }
 	}
 	
//error flag function for text field...........................

 function error_flag1($fieldName,$value) {
	global $errors2;
	$errorString="please enter valid ".$fieldName;
	
	$errors2[]=$errorString;
 } 	

//validation function for select field.........................

 function validation2($fieldName,$value,$name) {
	 global $existValue2;
 	if(trim($value)=='SELECT-' || trim($value)=="")
 	{
 		
 		error_flag2($fieldName,$value);
 		$existValue2[$name]=0;
 	}
 	 else {
 	 	$existValue2[$name]=1;
 	 	setcookie($name,$value);
 	 }
 }


//error flag function for select field...........................

 function error_flag2($fieldName,$value) {
     global $errors2;
	$errorString="please select a ".$fieldName;
	$errors2[]=$errorString;
 } 	
 
 
 function validation3($value,$name) {
 	     global $existValue2;
 		if(trim($value)=='-SELECT-' || trim($value)=="")
 	{
 		$existValue2[$name]=0;
		echo'in';
 	}
 	 else {
 	 	$existValue2[$name]=1;
		
 	 	setcookie($name,$value);
 	 }
 }



 $p=& $_POST;

 

 //$p['delType'];
 validation1('Name',$p['ename'],'ename');
 validation1('District',$p['dis'],'dis');
 validation1('Police Station',$p['ps'],'ps');
 validation1('Post Office',$p['po'],'po');
 validation1('Contact No',$p['cn'],'cn');
 validation1('Relationship',$p['rlt'],'rlt');
 validation2('Country',$p['ecountry'],'ecountry');
 validation2('Re-issue',$p['reissue'],'reissue');
 validation3($p['ofno'],'ofno');
 validation3($p['resno'],'resno');
 validation3($p['mobno'],'mobno');
 validation3($p['vh'],'vh');
 validation3($p['rbs'],'rbs');
 validation3($p['email'],'email');
 validation3($p['passNo'],'passNo');
 validation3($p['poi'],'poi');
 validation3($p['doi'],'doi');
  

  



  setcookie('existValue2',json_encode($existValue2));
    
   if(!empty($errors2))
   {
   	$ew="fieldError2";
     echo "in";
   setcookie($ew,json_encode($errors2));
  // setcookie('check',json_encode($fieldsOfError));
 
  }
  else{
	   echo "out";
	  setcookie('fieldError2','',time()-3600);
  }
 
 	header('Location: http://localhost/assignment/pages/stage3.php');
?>