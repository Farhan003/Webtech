
<!DOCTYPE html>
<html>
<head>
	<title>
		Frequency counter
	</title>
</head>
<body>
	<hr style="color: green;,margin-top:20px">
	<h2 style="margin-top:3px;,text-align:center;"> Character Frequency</h2>
	<hr style="color:green; ">
	<p>Insert string to count</p>
	<form action="Frequencyshow.php" name="frequencyCounter" method="post" >
		<textarea rows="4" cols="50" name="v1" ></textarea>
		<input type="submit" value="submit">
	</form>

</body>
</html>